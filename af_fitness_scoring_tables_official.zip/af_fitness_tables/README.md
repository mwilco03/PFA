# Department of the Air Force (DAF) Fitness Assessment Scoring Tables (Official PDFs)

## What’s included
This folder contains official, source PDFs from the Air Force Personnel Center (AFPC) Fitness Program page.

### 1) “Current Fitness Charts” (legacy scoring tables)
- File: `Current_Fitness_Charts_5_Year_Chart_Scoring_Including_Optional_Component_Standards_20211111_0219.pdf`
- Source (AFPC): https://www.afpc.af.mil/Career-Management/Fitness-Program/ (link text: “Current Fitness Charts”)

### 2) “New Fitness Charts 23 Sep 25” (updated scoring tables)
- File: `PT_Charts_New_50-20-15-15_with_2Mile_FINAL_23_Sep_2025.pdf`
- Source (AFPC): https://www.afpc.af.mil/Career-Management/Fitness-Program/ (link text: “New Fitness Charts 23 Sep 25”)

### 3) DTM memo that announces the upcoming changes
- File: `DTM_Fitness_SAF_MR_Signed_23_Sep_2025.pdf`
- Source (AFPC): https://www.afpc.af.mil/Career-Management/Fitness-Program/ (link text: “DTM Fitness SAF MR Signed 23 Sep 25”)

### 4) DAFMAN 36-2905 (Fitness Program)
- File: `DAFMAN_36-2905.pdf`
- Source (AFPC): https://www.afpc.af.mil/Career-Management/Fitness-Program/ (link text: “DAFMAN 36-2905 (Click to download)”)

## Notes on currency / effective dates
- The DTM states the new standards are implemented on **1 Sep 2026**, with a diagnostic period starting **1 Mar 2026**.
- The “New Fitness Charts 23 Sep 25” PDF includes the updated component mix and point distribution described in the DTM.

## Downloaded
- Retrieved on: 2026-02-22 (America/Denver)
